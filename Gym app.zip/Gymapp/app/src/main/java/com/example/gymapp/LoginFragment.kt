package com.example.gymapp

import android.os.Bundle
import android.util.Patterns
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.example.gymapp.databinding.FragmentLoginBinding
import com.google.firebase.auth.FirebaseAuth

class LoginFragment : Fragment() {

    private lateinit var binding: FragmentLoginBinding
    private lateinit var auth: FirebaseAuth


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        auth = FirebaseAuth.getInstance()
        binding = FragmentLoginBinding.inflate(inflater)
        val view = binding.root


        return view
    }


    private fun Login(){
        val email = binding.email.toString()
        val password = binding.password.toString()

        when{
            email.isEmpty() -> Toast.makeText(requireActivity(), "Please write your email", Toast.LENGTH_LONG).show()
            password.isEmpty() -> Toast.makeText(requireActivity(), "Please write your password", Toast.LENGTH_LONG).show()
            Patterns.EMAIL_ADDRESS.matcher(email).matches() -> Toast.makeText(requireActivity(), "Please enter valid email", Toast.LENGTH_LONG).show()
            else -> auth.signInWithEmailAndPassword(email,password)
                .addOnCompleteListener (requireActivity()){task ->
                    if (task.isSuccessful){
                        val user = auth.currentUser


                    } else{
                        Toast.makeText(requireActivity(), "Login failed", Toast.LENGTH_SHORT).show()
                    }

                }
        }

    }


    }

